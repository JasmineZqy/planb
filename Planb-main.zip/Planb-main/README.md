# Partial Matching
## Goal
To make the recognized clinical variables by NILE be more specific and well-organized for research use, concept partial matching is performed to match all the strings under the identified medical concepts to associated grouped structured EHR data. 
## Descrption
Typically, four domains of codified data in EHR including diagnosis, procedures, laboratory measurements, and medications are considered for this file.


# Getting started
This section contains required documents download links and libraries in R.
## Document links
* UMLS website: https://www.nlm.nih.gov/research/umls/index.html
* CUIs and terms in UMLS system: https://www.ncbi.nlm.nih.gov/books/NBK9685/table/ch03.T.concept_names_and_sources_file_mr/
* PheWAS catalog: https://phewascatalog.org/phecodes
* ICD-9-CM and ICD-9-PCS: https://www.cms.gov/Medicare/Coding/ICD9ProviderDiagnosticCodes/codes
* ICD-10-CM: https://www.cms.gov/medicare/icd-10/2022-icd-10-cm
* ICD-10-PCS: https://www.cms.gov/medicare/icd-10/2022-icd-10-pcs
* CPT/HCPCS Codes: [https://www.cms.gov/medicare/hcpcs-general-information/hcpcs-level-ii-archive](https://www.cms.gov/medicare/fraud-and-abuse/physicianselfreferral/list_of_codes)
* CCS for CPT/HCPCS: https://www.hcup-us.ahrq.gov/toolssoftware/ccs_svcsproc/ccscpt_downloading.jsp
* CCS for ICD-10-PCS: https://www.hcup-us.ahrq.gov/toolssoftware/ccs10/ccs10.jsp
* CCS for ICD-9-CM: https://www.hcup-us.ahrq.gov/toolssoftware/ccs/ccs.jsp
* RxNorm codes: https://www.nlm.nih.gov/research/umls/rxnorm/docs/rxnormfiles.html
* LOINC: https://loinc.org/downloads/
## Libraries
```
library('readxl')
library("tidyr")
library(dplyr)
library(stringi)
library(stringr)
library(plyr)
```

# Cuiterms Filtering

In UMLS, each CUI represents one concept which has multiple names and aliases as strings.
We collect all strings under the recognized CUIs by NILE after deleting words of length less than 4 characters which is uninformative for partial matching.

## CUIs and terms dictionary
Import MRCONSO.RRF file and output the whole cuiterms dictionary.
```
conso<-read.delim(file = "/Users/zengqingyi/Desktop/planb/umsl/2022AA/META/MRCONSO.RRF", sep='|',header = F)
data <- subset(conso,V2 == 'ENG',select = c('V1','V15'))
names(data)[1] <- 'CUI'
names(data)[2] <- 'string'
write.csv(data,"/Users/zengqingyi/Desktop/planb/umsl/cui.csv",row.names = FALSE)
```
## Cuiterm dicationary subset
```
cuidic <- read.csv("/Users/zengqingyi/Desktop/planb/draft/new/cui.csv", header=FALSE,strip.white=TRUE)
cuidic$V1 <- NULL
cuidic <- tail(cuidic,-2)
colnames(cuidic) <- c('cuiterm','cui')
example <- read.csv("/Users/zengqingyi/Desktop/project/partial_matching/p1_label_c.csv",header=TRUE)
listdata1<-list()
for (i in 1:nrow(example)) {dfcui <- cuidic[grep(example$cui[i],cuidic$cui),] 
listdata1[[i]] <-dfcui}
listdata1clear <- list()
for (j in 1:length(listdata1)){
  listdata1clear[[j]] <- subset(listdata1[[j]],nchar(cuiterm)>4)
}
table_cui <- bind_rows(listdata1clear)
table_cui<- distinct(table_cui)
```
# Partial matching function
```
partial_join <- function(x, y, by_x, pattern_y,type='type') {
 idx_x <- sapply(y[[pattern_y]], grep, x[[by_x]],fixed=TRUE,ignore.case=TRUE,useBytes = FALSE)
 idx_y <- sapply(seq_along(idx_x), function(i) rep(i, length(idx_x[[i]])))
 df <- dplyr::bind_cols(x[unlist(idx_x), , drop = F],
                        y[unlist(idx_y), , drop = F]) 
 df_s <-df%>% mutate( score=( str_count(df[[pattern_y]],'\\s+')+1 )/ ( str_count(df[[by_x]],'\\s+')+1 ) )
 df_s$type=type
 return(df_s)
}
```

# Diagnosis domain
We utilize strings from concept identification to partially match the ICD-to-Phecode mapping chart obtained from PheWas catalog for more general diagnosis. Phecode-ICD9cm and Phecode-ICD10cm are concatenated as a whole Phecode-ICD codes and matched by the strings extracted from NILE separatly which  are regarded as a complete matching pattern ignoring case. 
## Phecode-ICD dictionary concatenation
```
phecode_icd9 <- read.csv("/Users/zengqingyi/Desktop/planb/phecode/1.2_icd9/phecode_icd9_rolled.csv", header=TRUE)
phecode_icd10cm<- read.csv("/Users/zengqingyi/Desktop/planb/phecode/1.2_icd10cm/Phecode_map_v1_2_icd10cm_beta.csv", header=TRUE)
dficd9 <- subset(phecode_icd9,select=-c(Ignore.Bool))
names(phecode_icd10cm) <- names(dficd9)
phecode_icd<- rbind(dficd9,phecode_icd10cm)
```
## Phecode partial matching
### Matching for phecode and exclphecode
```
phecode_icd$Phenotype <- tolower(phecode_icd$Phenotype)
phecode_icd$Excl..Phenotypes <- tolower(phecode_icd$Excl..Phenotypes)
phecode <- phecode_icd %>% select('PheCode','Phenotype')
colnames(phecode)[colnames(phecode)=='PheCode'] <- 'code'
colnames(phecode)[colnames(phecode)=='Phenotype'] <- 'des'
exclphecode <- phecode_icd %>% select('Excl..Phecodes','Excl..Phenotypes')
colnames(exclphecode)[colnames(exclphecode)=='Excl..Phecodes'] <- 'code'
colnames(exclphecode)[colnames(exclphecode)=='Excl..Phenotypes'] <- 'des'
phecode_matching <- partial_join(phecode, table_cui0, by_x = 'des', pattern_y = 'cuiterm',type='phecode')
exclphecode_matching <- partial_join(exclphecode, table_cui0, by_x = 'des', pattern_y = 'cuiterm',type='exclphecode')
```
### Matching for ICD codes
```
icd <- phecode_icd %>% select('ICD9','ICD9.String')
colnames(icd)[colnames(icd)=='ICD9'] <- 'code'
colnames(icd)[colnames(icd)=='ICD9.String'] <- 'des'
icd <- distinct(icd)
icd_matching <- partial_join(icd, table_cui0, by_x = 'des', pattern_y = 'cuiterm',type='icd')
```
The final results for the diagnosis domain involve the matched ICD codes and their corresponding descriptions, Phecode and phenotypes, excluded Phecode range and phenotype. 

# Procedure domain
Commonly-used codes include CPT (The Current Procedural Terminology) developed by American Medical Association (AMA), ICD-Procedure Coding System (ICD-10-PS), ICD-9-PCS (used to report procedures for inpatient hospital services in ICD-9-CM), HCPCS ( Health Care Procedure Coding System based on CPT). Procedural codes except for medication from these above coding systems are grouped into clinical classification software (CCS) categories and matched by the string patterns from NILE similar to diagnosis domain and their codes and corresponding descriptions will be recorded in the final chart.
## Import CPT, ICD-10-PS, ICD-9-PCS, HCPCS CSS categories
```
cpt <- read_excel('/Users/zengqingyi/Desktop/planb/3domain/CCS/ccsm/cpt:HCPCS.xlsx')
colnames(cpt) <- c('cpt','cpt_des')
cptcss <- read.csv('/Users/zengqingyi/Desktop/planb/3domain/CCS/ccsm/cptccs.csv')
colnames(cptcss) <- c('cpt_range','ccs_cpt','ccs_cpt_des')
icd9sin <- read.csv('/Users/zengqingyi/Desktop/planb/3domain/CCS/ccsm/sinicd9.csv')
colnames(icd9sin) <- c('icd9','icd9ccs','icd9ccs_des','icd9_shortdes')
icd9mult <- read.csv('/Users/zengqingyi/Desktop/planb/3domain/CCS/ccsm/multicd9.csv')
colnames(icd9mult) <- c('icd9','icd9ccs_l1','icd9ccs_l1_des','icd9ccs_l2','icd9ccs_l2_des','icd9ccs_l3','icd9ccs_l3_des')
icd10m <- read.csv('/Users/zengqingyi/Desktop/planb/3domain/CCS/ccsm/icd10pcs.CSV')
colnames(icd10m) <- c('icd10','icd10_des','ccs_icd10_code','ccs_icd10_des','clinical_domain')
```

## Macthing for CPT and HCPCS

```
cpt$cpt_des <- tolower(cpt$cpt_des)
colnames(cpt)[colnames(cpt)=='cpt'] <- 'code'
colnames(cpt)[colnames(cpt)=='cpt_des'] <- 'des'
cpt_matching <- partial_join(cpt, table_cui0, by_x = 'des', pattern_y = 'cuiterm',type='CPT')
```
## Macthing for CPT-CSS
```
cptcss$ccs_cpt_des <- tolower(cptcss$ccs_cpt_des)
colnames(cptcss)[colnames(cptcss)=='ccs_cpt'] <- 'code'
colnames(cptcss)[colnames(cptcss)=='cpt_cpt_des'] <- 'des'
cptcss$cpt_range <- NULL
cptcss_matching <- partial_join(cptcss, table_cui0, by_x = "des", pattern_y = "cuiterm",type='CPTCSS')
```
## Matching for ICD9-CSS
```
icd9sin$icd9_shortdes <- tolower(icd9sin$icd9_shortdes)
icd9sin$icd9 <- NULL
icd9sin$icd9_shortdes <- NULL
colnames(icd9sin)[colnames(icd9sin)=='icd9ccs'] <- 'code'
colnames(icd9sin)[colnames(icd9sin)=='icd9ccs_des'] <- 'des'
icd9sin_matching <- partial_join(icd9sin, table_cui0, by_x = "des", pattern_y = "cuiterm",type='icd9sincss')
icd9sin_matching <- distinct(icd9sin_matching)

colnames(icd9mult) <- c('code','des')
icd9ml_matching <- partial_join(icd9mult, table_cui0, by_x = "des", pattern_y = "cuiterm",type='icd9multcss')
icd9ml_matching <-distinct(icd9ml_matching)
```
## Matching for ICD10-CSS
```
icd10m$icd10_des <- tolower(icd10m$icd10_des)
colnames(icd10m)[colnames(icd10m)=='ccs_icd10_code'] <- 'code'
colnames(icd10m)[colnames(icd10m)=='ccs_icd10_des'] <- 'des'
icd10m$icd10 <- NULL
icd10m$icd10_des <- NULL
icd10m$clinical_domain <- NULL
ccs_icd10_matching <- partial_join(icd10m, table_cui0, by_x = "des", pattern_y = "cuiterm",type='icd10css')
ccs_icd10_matching <- distinct(ccs_icd10_matching)
```
# Medication domain
## Matching for Rxnorm
```
conso<-read.delim(file = "/Users/zengqingyi/Desktop/planb/3domain/Rxnorm/RxNorm_full_10032022/rrf/RXNCONSO.RRF",sep='|',header = F)
rxn <- conso %>% filter(V2=='ENG') %>% select('V1','V15')
colnames(rxn) <- c('code','des')
rxn_matching <- partial_join(rxn, table_cui0 ,by_x = "des", pattern_y = "cuiterm",type='rxn')

```
# Laboratory domain
## Matching for Lonic
```
lonic<-read.csv( "/Users/zengqingyi/Desktop/project/partial_matching/data/LoincTableCore.csv")
lon <- lonic %>% select('LOINC_NUM','COMPONENT')
colnames(lon) <- c('code','des')
rlonic_matching <- partial_join(lon, table_cui0 ,by_x = "des", pattern_y = "cuiterm",type='Lonic')
```
# Combination for all domains
```
paper1_strucmat <- bind_rows(phecode_matching,exclphecode_matching,icd_matching,cpt_matching,ccs_icd10_matching,icd9sin_matching,icd9ml_matching)
paper1_strucmat <- distinct(paper1_strucmat)
paper1_strucmat %>%ungroup()
combination <- paper1_strucmat %>%group_by(cui,type) %>% unique() %>% filter(row_number()==1)
setorder(combination,cui)
```

